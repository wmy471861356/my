#ifndef __BEEP_H_
#define __BEEP_H_

extern void beep_Init(void);

#endif